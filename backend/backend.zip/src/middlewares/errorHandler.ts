import { Request, Response, NextFunction } from "express";

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  console.error("Error capturado:", err.message);
  res.status(500).json({
    mensaje: "Error interno del servidor",
    detalle: err.message,
  });
}
