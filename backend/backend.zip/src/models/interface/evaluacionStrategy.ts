export interface evaluacionStrategy {
    evaluar(respuestas: any): number;
}