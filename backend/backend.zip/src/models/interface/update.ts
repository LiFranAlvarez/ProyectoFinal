export interface Update {
    update(mensaje: string): void;
}